
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import axios from 'axios';
import pg from 'pg';

const { Pool } = pg;
const app = express();
app.use(cors());
app.use(bodyParser.json());

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function init() {
  try {
    const fs = await import('node:fs/promises');
    const schema = await fs.readFile('./schema.sql', 'utf-8');
    await pool.query(schema);
    console.log('DB schema ensured');
  } catch (e) {
    console.error('Schema init error', e);
  }
}
init();

const AGG = (process.env.AGGREGATOR || 'belvo').toLowerCase();

function inferCategory(description='') {
  const d = description.toLowerCase();
  const rules = [
    { key: 'moradia', words: ['aluguel','condom','boleto','energia','água','luz'] },
    { key: 'alimentação', words: ['padaria','mercado','supermerc','acai','ifood','restaurante'] },
    { key: 'transporte', words: ['posto','uber','99','estacionamento'] },
    { key: 'saúde', words: ['clínica','farmácia','consulta'] },
    { key: 'assinaturas', words: ['spotify','netflix','prime','apple','openai','chatgpt'] },
    { key: 'lazer', words: ['cinema','evento','tickets','viagem'] },
    { key: 'educação', words: ['curso','escola','faculdade','linux'] },
    { key: 'pet', words: ['cobasi','petz'] },
  ];
  for (const r of rules) if (r.words.some(w => d.includes(w))) return r.key;
  return 'diversos';
}

// --------- Helpers de persistência ---------
async function upsertInstitution(client, aggregator, external_id, name) {
  const res = await client.query(
    `INSERT INTO institutions(aggregator, external_id, name)
     VALUES($1,$2,$3)
     ON CONFLICT(external_id) DO UPDATE SET name=EXCLUDED.name
     RETURNING id`,
    [aggregator, external_id, name]
  );
  return res.rows[0].id;
}
async function upsertAccount(client, inst_id, external_id, name, type, currency, balance) {
  const res = await client.query(
    `INSERT INTO accounts(institution_id, external_id, name, type, currency, balance)
     VALUES($1,$2,$3,$4,$5,$6)
     ON CONFLICT(external_id) DO UPDATE SET name=EXCLUDED.name, type=EXCLUDED.type, currency=EXCLUDED.currency, balance=EXCLUDED.balance
     RETURNING id`,
    [inst_id, external_id, name, type, currency, balance]
  );
  return res.rows[0].id;
}
async function upsertTransaction(client, account_id, external_id, description, category, amount, currency, booking_date, raw) {
  const res = await client.query(
    `INSERT INTO transactions(account_id, external_id, description, category, amount, currency, booking_date, raw)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8)
     ON CONFLICT(external_id) DO NOTHING
     RETURNING id`,
    [account_id, external_id, description, category, amount, currency, booking_date, raw]
  );
  return res.rows[0]?.id;
}

// --------- Stubs dos agregadores (trocar por chamadas reais) ---------
async function belvoLinkToken() { return { linkUrl: 'https://belvo-link.example/connect' }; }
async function pluggyLinkToken() { return { linkUrl: 'https://connect.pluggy.ai/' }; }

async function pullDataMock() {
  return {
    institution: { id: 'bank_itau_123', name: 'Itaú' },
    accounts: [
      { id: 'acc_1', name: 'Conta Corrente', type: 'checking', currency: 'BRL', balance: 3250.55 },
      { id: 'acc_2', name: 'Cartão Crédito', type: 'credit', currency: 'BRL', balance: -2450.12 }
    ],
    transactions: [
      { id: 'tx_1', accountId: 'acc_1', description: 'Supermercado', amount: 120.35, currency: 'BRL', bookingDate: '2025-08-05' },
      { id: 'tx_2', accountId: 'acc_1', description: 'Posto de combustível', amount: 180.00, currency: 'BRL', bookingDate: '2025-08-06' }
    ]
  };
}

// --------- Rotas ---------
app.post('/api/link/token', async (req, res) => {
  try {
    const token = AGG === 'pluggy' ? await pluggyLinkToken() : await belvoLinkToken();
    res.json(token);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'failed_to_create_link_token' });
  }
});

app.post('/api/sync/start', async (req, res) => {
  try {
    const client = await pool.connect();
    try {
      const data = await pullDataMock(); // troque por agregador real
      const instId = await upsertInstitution(client, AGG, data.institution.id, data.institution.name);
      const accountIdMap = {};
      for (const a of data.accounts) {
        const id = await upsertAccount(client, instId, a.id, a.name, a.type, a.currency, a.balance);
        accountIdMap[a.id] = id;
      }
      for (const t of data.transactions) {
        await upsertTransaction(
          client,
          accountIdMap[t.accountId],
          t.id,
          t.description,
          inferCategory(t.description),
          t.amount,
          t.currency,
          t.bookingDate,
          t
        );
      }
      res.json({ ok: true });
    } finally {
      client.release();
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'sync_failed' });
  }
});

app.get('/api/accounts', async (req, res) => {
  const r = await pool.query('SELECT * FROM accounts ORDER BY id DESC');
  res.json(r.rows);
});

app.get('/api/transactions', async (req, res) => {
  const { from, to } = req.query;
  const params = [];
  let where = [];
  if (from) { params.push(from); where.push(`booking_date >= $${params.length}`); }
  if (to) { params.push(to); where.push(`booking_date <= $${params.length}`); }
  const sql = `SELECT * FROM transactions ${where.length? 'WHERE ' + where.join(' AND ') : ''} ORDER BY booking_date DESC, id DESC LIMIT 500`;
  const r = await pool.query(sql, params);
  res.json(r.rows);
});

app.post('/api/webhook', async (req, res) => {
  // TODO: validar assinatura com WEBHOOK_SECRET (agregador envia header de assinatura)
  // Por enquanto só loga e ACK.
  console.log('Webhook received:', JSON.stringify(req.body).slice(0,500));
  res.json({ ok: true });
});

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`API running on :${port}`));
