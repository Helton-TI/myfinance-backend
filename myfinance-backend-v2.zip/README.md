
# MyFinance Backend v2

API de sincronização bancária (Belvo/Pluggy) para o app web.

## Rotas
- `POST /api/link/token` – inicia conexão segura com bancos (widget dos agregadores)
- `POST /api/sync/start` – força sincronização (mock nesta versão)
- `GET  /api/accounts` – lista contas
- `GET  /api/transactions?from=YYYY-MM-DD&to=YYYY-MM-DD` – lista transações
- `POST /api/webhook` – recebe eventos (transactions created/updated)

## Rodando local
```bash
cp .env.example .env
docker compose up -d db
# opcional: pré-criar schema
docker exec -i $(docker ps -qf name=db) psql -U postgres -d myfinance < schema.sql
npm install
npm run dev
```

## Produção (Railway)
- Crie Postgres (DATABASE_URL)
- Configure variáveis: PORT, DATABASE_URL, AGGREGATOR, credenciais do agregador, WEBHOOK_SECRET
- Deploy a partir do GitHub
