
CREATE TABLE IF NOT EXISTS institutions (
  id SERIAL PRIMARY KEY,
  aggregator TEXT NOT NULL,
  external_id TEXT NOT NULL UNIQUE,
  name TEXT
);

CREATE TABLE IF NOT EXISTS accounts (
  id SERIAL PRIMARY KEY,
  institution_id INTEGER REFERENCES institutions(id) ON DELETE CASCADE,
  external_id TEXT NOT NULL UNIQUE,
  name TEXT,
  type TEXT,
  currency TEXT,
  balance NUMERIC DEFAULT 0
);

CREATE TABLE IF NOT EXISTS transactions (
  id SERIAL PRIMARY KEY,
  account_id INTEGER REFERENCES accounts(id) ON DELETE CASCADE,
  external_id TEXT UNIQUE,
  description TEXT,
  category TEXT,
  amount NUMERIC NOT NULL,
  currency TEXT,
  booking_date DATE,
  raw JSONB
);
